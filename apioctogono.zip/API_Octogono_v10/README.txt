para executar a API, digite o comando npm start no terminal (necessário node.js instalado na máquina)
depois, abra o link https://octogono-final.vercel.app/ no seu navegador para visualizar a página.