const express = require('express');
const router = express.Router();

const ProfessorController = require('./controllers/ProfessorController');
const AlunoController = require('./controllers/AlunoController');
const MateriaController = require('./controllers/MateriaController');
const TurmaController = require('./controllers/TurmaController');


//rotas professores
router.get('/professores', ProfessorController.buscarTodos);
router.get('/professor/:id_professor', ProfessorController.buscarUm);

//rotas alunos

//rotas get
router.get('/alunos', AlunoController.buscarAlunos);
router.get('/aluno/:nome_aluno', AlunoController.buscaAlunoPorNome);
router.get('/alunos/:nome_turma', AlunoController.buscaAlunosPorTurma);
router.get('/alunos-prof/:id_turma', AlunoController.buscaAlunosPorProfessor);
router.get('/alunosfaltas', AlunoController.buscarFaltas);
router.get('/alunosfaltasmat', AlunoController.buscarFaltaMat);
router.get('/alunosfaltashist', AlunoController.buscarFaltaHist);
router.get('/alunosfaltascie', AlunoController.buscarFaltaCie);
router.get('/alunosfaltasart', AlunoController.buscarFaltaArt);
router.get('/alunosfaltasport', AlunoController.buscarFaltaPort);
router.get('/alunosfaltasing', AlunoController.buscarFaltaIng);
router.get('/alunosfaltasgeo', AlunoController.buscarFaltaGeo);
router.get('/alunosfaltasedf', AlunoController.buscarFaltaEdf);
router.get('/buscareprovados', AlunoController.buscarReprovados);


//rotas put
router.put('/aluno/adicionar-falta/:id_aluno', AlunoController.adicionarFalta);
router.put('/aluno/adicionar-falta-rest/:id_aluno', AlunoController.adicionarFaltaRest);
router.put('/aluno/adicionar-falta-mat/:id_aluno', AlunoController.adicionarFaltaMat);
router.put('/aluno/adicionar-falta-hist/:id_aluno', AlunoController.adicionarFaltaHist);
router.put('/aluno/adicionar-falta-cie/:id_aluno', AlunoController.adicionarFaltaCie);
router.put('/aluno/adicionar-falta-art/:id_aluno', AlunoController.adicionarFaltaArt);
router.put('/aluno/adicionar-falta-port/:id_aluno', AlunoController.adicionarFaltaPort);
router.put('/aluno/adicionar-falta-ing/:id_aluno', AlunoController.adicionarFaltaIng);
router.put('/aluno/adicionar-falta-geo/:id_aluno', AlunoController.adicionarFaltaGeo);
router.put('/aluno/adicionar-falta-edf/:id_aluno', AlunoController.adicionarFaltaEdf);
router.put('/aluno/reprova', AlunoController.reprovaAlunos);


router.put('/aluno/retirar-falta/:id_aluno', AlunoController.retirarFalta);


//rotas materias

router.get('/materias', MateriaController.buscarMaterias);

//rotas turmas
router.get('/turmas', TurmaController.buscarTurmas);
module.exports = router;



