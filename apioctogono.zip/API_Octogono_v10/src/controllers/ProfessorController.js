const ProfessorService = require('../services/ProfessorService');

module.exports = {
    buscarTodos: async (req, res) => {
        let json = { error: '', result: [] };

        let professores = await ProfessorService.buscarTodos();

        for (let i in professores) {
            json.result.push({
                id_professor: professores[i].id_professor,
                nome_professor: professores[i].nome_professor
            });
        }
        res.json(json);
    },

    
    buscarUm: async (req, res) => {
        let json = { error: '', result: {} };
    
        let id_professor = req.params.id_professor; // Acessa o parâmetro id_professor da requisição
        let professor = await ProfessorService.buscarUm(id_professor);
    
        if (professor) {
            json.result = professor;
        } else {
            json.error = 'Professor não encontrado';
        }
    
        res.json(json);
    }

    
    

}
    
