const TurmaService = require('../services/TurmaService');

module.exports = {
    buscarTurmas: async (req, res) => {
        let json = { error: '', result: [] };

        let turmas = await TurmaService.buscarTurmas();

        for (let i in turmas) {
            json.result.push({
                
                nome_turma: turmas[i].nome_turma
            });
        }
        res.json(json);
    }

    


}
    
