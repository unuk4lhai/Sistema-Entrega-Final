const AlunoService = require('../services/AlunoService');

module.exports = {

    adicionarFalta: async(req, res) => {
        let json = {error: '', result:{}};

        let id_aluno = req.params.id_aluno;
        let nome_aluno = req.body.nome_aluno;
        let n_de_faltas = req.body.n_de_faltas;

        if(id_aluno){
            await AlunoService.adicionarFalta(id_aluno);
            json.result = {
                nome_aluno,
                n_de_faltas
            };
        }else{
            json.error = 'campos não enviados';
        }

        res.json(json)
    },

    adicionarFaltaRest : async(req, res) => {
        let json = {error: '', result:{}};

        let id_aluno = req.params.id_aluno;
        let nome_aluno = req.body.nome_aluno;
        let faltas_rest = req.body.faltas_rest;

        if(id_aluno){
            await AlunoService.adicionarFaltaRest(id_aluno);
            json.result = {
                nome_aluno,
                faltas_rest
            };
        }else{
            json.error = 'campos não enviados';
        }

        res.json(json)
    },

    adicionarFaltaMat: async(req, res) => {
        let json = {error: '', result:{}};

        let id_aluno = req.params.id_aluno;
        let nome_aluno = req.body.nome_aluno;
        let falta_mat = req.body.falta_mat;

        if(id_aluno){
            await AlunoService.adicionarFaltaMat(id_aluno);
            json.result = {
                nome_aluno,
                falta_mat
            };
        }else{
            json.error = 'campos não enviados';
        }

        res.json(json)
    },


    adicionarFaltaHist: async(req, res) => {
        let json = {error: '', result:{}};

        let id_aluno = req.params.id_aluno;
        let nome_aluno = req.body.nome_aluno;
        let falta_hist = req.body.falta_hist;

        if(id_aluno){
            await AlunoService.adicionarFaltaHist(id_aluno);
            json.result = {
                nome_aluno,
                falta_hist
            };
        }else{
            json.error = 'campos não enviados';
        }

        res.json(json)
    },

    adicionarFaltaCie: async(req, res) => {
        let json = {error: '', result:{}};

        let id_aluno = req.params.id_aluno;
        let nome_aluno = req.body.nome_aluno;
        let falta_cie = req.body.falta_cie;

        if(id_aluno){
            await AlunoService.adicionarFaltaCie(id_aluno);
            json.result = {
                nome_aluno,
                falta_cie
            };
        }else{
            json.error = 'campos não enviados';
        }

        res.json(json)
    },

    adicionarFaltaArt: async(req, res) => {
        let json = {error: '', result:{}};

        let id_aluno = req.params.id_aluno;
        let nome_aluno = req.body.nome_aluno;
        let falta_art = req.body.falta_art;

        if(id_aluno){
            await AlunoService.adicionarFaltaArt(id_aluno);
            json.result = {
                nome_aluno,
                falta_art
            };
        }else{
            json.error = 'campos não enviados';
        }

        res.json(json)
    },

    adicionarFaltaPort: async(req, res) => {
        let json = {error: '', result:{}};

        let id_aluno = req.params.id_aluno;
        let nome_aluno = req.body.nome_aluno;
        let falta_port = req.body.falta_port;

        if(id_aluno){
            await AlunoService.adicionarFaltaPort(id_aluno);
            json.result = {
                nome_aluno,
                falta_port
            };
        }else{
            json.error = 'campos não enviados';
        }

        res.json(json)
    },

    adicionarFaltaIng: async(req, res) => {
        let json = {error: '', result:{}};

        let id_aluno = req.params.id_aluno;
        let nome_aluno = req.body.nome_aluno;
        let falta_ing = req.body.falta_ing;

        if(id_aluno){
            await AlunoService.adicionarFaltaIng(id_aluno);
            json.result = {
                nome_aluno,
                falta_ing
            };
        }else{
            json.error = 'campos não enviados';
        }

        res.json(json)
    },
    
    adicionarFaltaGeo: async(req, res) => {
        let json = {error: '', result:{}};

        let id_aluno = req.params.id_aluno;
        let nome_aluno = req.body.nome_aluno;
        let falta_geo = req.body.falta_geo;

        if(id_aluno){
            await AlunoService.adicionarFaltaGeo(id_aluno);
            json.result = {
                nome_aluno,
                falta_geo
            };
        }else{
            json.error = 'campos não enviados';
        }

        res.json(json)
    },

    adicionarFaltaEdf: async(req, res) => {
        let json = {error: '', result:{}};

        let id_aluno = req.params.id_aluno;
        let nome_aluno = req.body.nome_aluno;
        let falta_edf = req.body.falta_edf;

        if(id_aluno){
            await AlunoService.adicionarFaltaEdf(id_aluno);
            json.result = {
                nome_aluno,
                falta_edf
            };
        }else{
            json.error = 'campos não enviados';
        }

        res.json(json)
    },

    retirarFalta: async(req, res) => {
        let json = {error: '', result:{}};

        let id_aluno = req.params.id_aluno;
        let nome_aluno = req.body.nome_aluno;
        let n_de_faltas = req.body.n_de_faltas;

        if(id_aluno){
            await AlunoService.retirarFalta(id_aluno);
            json.result = {
                nome_aluno,
                n_de_faltas
            };
        }else{
            json.error = 'campos não enviados';
        }

        res.json(json)
    },

    reprovaAlunos: async (req, res) => {
        let json = { error: '', result: [] };
    
        let result = await AlunoService.reprovaAlunos();
    
        json.result = result;
    
        res.json(json);
    },

    buscarAlunos: async (req, res) => {
        let json = { error: '', result: [] };

        let alunos = await AlunoService.buscarAlunos();

        for (let i in alunos) {
            json.result.push({
                id_aluno: alunos[i].id_aluno,
                nome_aluno: alunos[i].nome_aluno,
                n_de_faltas: alunos[i].n_de_faltas,
                faltas_rest: alunos[i].faltas_rest,
                falta_mat: alunos[i].falta_mat,
                falta_hist: alunos[i].falta_hist,
                falta_cie: alunos[i].falta_cie,
                falta_art: alunos[i].falta_art,
                falta_geo: alunos[i].falta_geo,
                falta_ing: alunos[i].falta_ing,
                falta_edf: alunos[i].falta_edf,
                falta_port: alunos[i].falta_port


            });
        }
        res.json(json);
    },

    buscaAlunoPorNome: async (req, res) => {
        let json = { error: '', result: {} };
    
        let nome_aluno = req.params.nome_aluno; // Acessa o parâmetro nome_aluno da requisição
        let aluno = await AlunoService.buscaAlunoPorNome(nome_aluno);
    
        if (aluno) {
            json.result = aluno;
        } else {
            json.error = 'aluno não encontrado';
        }
    
        res.json(json);
    },

    buscaAlunosPorTurma: async (req, res) => {
        let json = { error: '', result: [] };
    
        let nome_turma = req.params.nome_turma; // Acessa o parâmetro nome_turma da requisição
        let alunos = await AlunoService.buscaAlunosPorTurma(nome_turma);
    
        if (alunos.length > 0) {
            for (let i in alunos) {
                json.result.push({
                    id_aluno: alunos[i].id_aluno,
                    nome_aluno: alunos[i].nome_aluno,
                    n_de_faltas: alunos[i].n_de_faltas,
                    faltas_rest: alunos[i].faltas_rest,
                    falta_mat: alunos[i].falta_mat,
                    falta_hist: alunos[i].falta_hist,
                    falta_cie: alunos[i].falta_cie,
                    falta_art: alunos[i].falta_art,
                    falta_geo: alunos[i].falta_geo,
                    falta_ing: alunos[i].falta_ing,
                    falta_edf: alunos[i].falta_edf,
                    falta_port: alunos[i].falta_port
                });
            }
        } else {
            json.error = 'Nenhum aluno encontrado para esta turma';
        }
        res.json(json);
    },

    buscaAlunosPorProfessor: async (req, res) => {
        let json = { error: '', result: [] };
    
        let id_turma = req.params.id_turma; // Acessa o parâmetro id_turma da requisição
        let alunos = await AlunoService.buscaAlunosPorProfessor(id_turma);
    
        if (alunos.length > 0) {
            for (let i in alunos) {
                json.result.push({
                    id_aluno: alunos[i].id_aluno,
                    nome_aluno: alunos[i].nome_aluno,
                    faltas_rest: alunos[i].faltas_rest
                });
            }
        } else {
            json.error = 'Nenhum aluno encontrado para esta turma';
        }
    
        res.json(json);
    },

    buscarFaltas: async (req, res) => {
        let json = { error: '', result: [] };

        let alunos = await AlunoService.buscarFaltas();

        for (let i in alunos) {
            json.result.push({
                id_aluno: alunos[i].id_aluno,
                nome_aluno: alunos[i].nome_aluno,
                n_de_faltas: alunos[i].n_de_faltas,


            });
        }
        res.json(json);
    },


    buscarFaltaMat: async (req, res) => {
        let json = { error: '', result: [] };

        let alunos = await AlunoService.buscarFaltaMat();

        for (let i in alunos) {
            json.result.push({
                id_aluno: alunos[i].id_aluno,
                nome_aluno: alunos[i].nome_aluno,
                falta_mat: alunos[i].falta_mat,


            });
        }
        res.json(json);
    },

    buscarFaltaHist: async (req, res) => {
        let json = { error: '', result: [] };

        let alunos = await AlunoService.buscarFaltaHist();

        for (let i in alunos) {
            json.result.push({
                id_aluno: alunos[i].id_aluno,
                nome_aluno: alunos[i].nome_aluno,
                falta_hist: alunos[i].falta_hist,


            });
        }
        res.json(json);
    },


    buscarFaltaCie: async (req, res) => {
        let json = { error: '', result: [] };

        let alunos = await AlunoService.buscarFaltaCie();

        for (let i in alunos) {
            json.result.push({
                id_aluno: alunos[i].id_aluno,
                nome_aluno: alunos[i].nome_aluno,
                falta_cie: alunos[i].falta_cie,


            });
        }
        res.json(json);
    },

    buscarFaltaArt: async (req, res) => {
        let json = { error: '', result: [] };

        let alunos = await AlunoService.buscarFaltaArt();

        for (let i in alunos) {
            json.result.push({
                id_aluno: alunos[i].id_aluno,
                nome_aluno: alunos[i].nome_aluno,
                falta_art: alunos[i].falta_art,


            });
        }
        res.json(json);
    },

    buscarFaltaPort: async (req, res) => {
        let json = { error: '', result: [] };

        let alunos = await AlunoService.buscarFaltaPort();

        for (let i in alunos) {
            json.result.push({
                id_aluno: alunos[i].id_aluno,
                nome_aluno: alunos[i].nome_aluno,
                falta_port: alunos[i].falta_port,


            });
        }
        res.json(json);
    },

    buscarFaltaIng: async (req, res) => {
        let json = { error: '', result: [] };

        let alunos = await AlunoService.buscarFaltaIng();

        for (let i in alunos) {
            json.result.push({
                id_aluno: alunos[i].id_aluno,
                nome_aluno: alunos[i].nome_aluno,
                falta_ing: alunos[i].falta_ing,


            });
        }
        res.json(json);
    },


    buscarFaltaGeo: async (req, res) => {
        let json = { error: '', result: [] };

        let alunos = await AlunoService.buscarFaltaGeo();

        for (let i in alunos) {
            json.result.push({
                id_aluno: alunos[i].id_aluno,
                nome_aluno: alunos[i].nome_aluno,
                falta_geo: alunos[i].falta_geo,


            });
        }
        res.json(json);
    },

    buscarFaltaEdf: async (req, res) => {
        let json = { error: '', result: [] };

        let alunos = await AlunoService.buscarFaltaEdf();

        for (let i in alunos) {
            json.result.push({
                id_aluno: alunos[i].id_aluno,
                nome_aluno: alunos[i].nome_aluno,
                falta_edf: alunos[i].falta_edf,


            });
        }
        res.json(json);
    },

    buscarReprovados: async (req, res) => {
        let json = { error: '', result: [] };

        let alunos = await AlunoService.buscarReprovados();

        for (let i in alunos) {
            json.result.push({
                id_aluno: alunos[i].id_aluno,
                nome_aluno: alunos[i].nome_aluno,
                n_de_faltas: alunos[i].n_de_faltas,
                reprovado: alunos[i].reprovado

            });
        }
        res.json(json);
    },
    

}