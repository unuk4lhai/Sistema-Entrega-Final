const MateriaService = require('../services/MateriaService');

module.exports = {
    buscarMaterias: async (req, res) => {
        let json = { error: '', result: [] };

        let materias = await MateriaService.buscarMaterias();

        for (let i in materias) {
            json.result.push({
                
                nome_materia: materias[i].nome_materia
            });
        }
        res.json(json);
    }

}
    
