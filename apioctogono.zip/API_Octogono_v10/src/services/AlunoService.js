const db= require('../db');

module.exports= {

    adicionarFalta: (id_aluno) => {
        return new Promise((aceito,rejeitado)=>{

            db.query('UPDATE Aluno SET n_de_faltas = n_de_faltas+1 WHERE id_aluno = ?',
                [id_aluno],
                (error, results)=>{
                    if(error) {rejeitado(error); return; }
                    aceito(results);
                }
            );
        });
    },

    adicionarFaltaRest: (id_aluno) => {
        return new Promise((aceito,rejeitado)=>{

            db.query('UPDATE Aluno SET faltas_rest = faltas_rest+1 WHERE id_aluno = ?',
                [id_aluno],
                (error, results)=>{
                    if(error) {rejeitado(error); return; }
                    aceito(results);
                }
            );
        });
    },

    adicionarFaltaMat: (id_aluno) => {
        return new Promise((aceito,rejeitado)=>{

            db.query('UPDATE Aluno SET falta_mat = falta_mat+1 WHERE id_aluno = ?',
                [id_aluno],
                (error, results)=>{
                    if(error) {rejeitado(error); return; }
                    aceito(results);
                }
            );
        });
    },

    adicionarFaltaHist: (id_aluno) => {
        return new Promise((aceito,rejeitado)=>{

            db.query('UPDATE Aluno SET falta_hist = falta_hist+1 WHERE id_aluno = ?',
                [id_aluno],
                (error, results)=>{
                    if(error) {rejeitado(error); return; }
                    aceito(results);
                }
            );
        });
    },

    adicionarFaltaCie: (id_aluno) => {
        return new Promise((aceito,rejeitado)=>{

            db.query('UPDATE Aluno SET falta_cie = falta_cie+1 WHERE id_aluno = ?',
                [id_aluno],
                (error, results)=>{
                    if(error) {rejeitado(error); return; }
                    aceito(results);
                }
            );
        });
    },

    adicionarFaltaArt: (id_aluno) => {
        return new Promise((aceito,rejeitado)=>{

            db.query('UPDATE Aluno SET falta_art = falta_art+1 WHERE id_aluno = ?',
                [id_aluno],
                (error, results)=>{
                    if(error) {rejeitado(error); return; }
                    aceito(results);
                }
            );
        });
    },

    adicionarFaltaPort: (id_aluno) => {
        return new Promise((aceito,rejeitado)=>{

            db.query('UPDATE Aluno SET falta_port = falta_port+1 WHERE id_aluno = ?',
                [id_aluno],
                (error, results)=>{
                    if(error) {rejeitado(error); return; }
                    aceito(results);
                }
            );
        });
    },

    adicionarFaltaIng: (id_aluno) => {
        return new Promise((aceito,rejeitado)=>{

            db.query('UPDATE Aluno SET falta_ing = falta_ing+1 WHERE id_aluno = ?',
                [id_aluno],
                (error, results)=>{
                    if(error) {rejeitado(error); return; }
                    aceito(results);
                }
            );
        });
    },

    adicionarFaltaGeo: (id_aluno) => {
        return new Promise((aceito,rejeitado)=>{

            db.query('UPDATE Aluno SET falta_geo = falta_geo+1 WHERE id_aluno = ?',
                [id_aluno],
                (error, results)=>{
                    if(error) {rejeitado(error); return; }
                    aceito(results);
                }
            );
        });
    },
    
    adicionarFaltaEdf: (id_aluno) => {
        return new Promise((aceito,rejeitado)=>{

            db.query('UPDATE Aluno SET falta_edf = falta_edf+1 WHERE id_aluno = ?',
                [id_aluno],
                (error, results)=>{
                    if(error) {rejeitado(error); return; }
                    aceito(results);
                }
            );
        });
    },

    

    retirarFalta: (id_aluno) => {
        return new Promise((aceito,rejeitado)=>{

            db.query('UPDATE Aluno SET n_de_faltas = n_de_faltas-1 WHERE id_aluno = ?',
                [id_aluno],
                (error, results)=>{
                    if(error) {rejeitado(error); return; }
                    aceito(results);
                }
            );
        });
    },

    reprovaAlunos: () => {
        return new Promise((aceito, rejeitado) => {
            db.query('UPDATE Aluno SET reprovado = true WHERE n_de_faltas > 8', 
            (error, results) => {
                if (error) { 
                    rejeitado(error); 
                    return; 
                }
                aceito(results);
            });
        });
    },
    



    //metodos get


    buscarAlunos: () =>{
        return new Promise ((aceito, rejeitado)=>{

            db.query ('SELECT * FROM Aluno', (error, results)=>{
                if (error){rejeitado(error); return; }
                aceito(results);
            });
        });
    },


    buscaAlunoPorNome: (nome_aluno) => {
        return new Promise((aceito, rejeitado)=>{

            db.query('SELECT *FROM Aluno WHERE nome_aluno = ?', [nome_aluno], (error, results)=>{
                if (error){rejeitado(error); return;}
                if (results.length>0){
                    aceito(results[0]);
                } else{ 
                    aceito(false);
                }
            });
        });
    },

    buscaAlunosPorTurma: (nome_turma) => {
        return new Promise((aceito, rejeitado) => {
            db.query('SELECT * FROM Aluno WHERE id_turma = ?', [nome_turma], (error, results) => {
                if (error) {
                    rejeitado(error);
                    return;
                }
                aceito(results); // Retorna todos os resultados encontrados
            });
        });
    },

    buscaAlunosPorProfessor: (id_turma) => {
        return new Promise((aceito, rejeitado) => {
            db.query('SELECT id_aluno, nome_aluno, faltas_rest FROM Aluno WHERE id_turma = ? AND faltas_rest> 0', [id_turma], (error, results) => {
                if (error) {
                    rejeitado(error);
                    return;
                }
                aceito(results); // Retorna todos os resultados encontrados
            });
        });
    },

    buscarFaltas: () =>{
        return new Promise ((aceito, rejeitado)=>{

            db.query ('SELECT * FROM Aluno WHERE n_de_faltas > 0', (error, results)=>{
                if (error){rejeitado(error); return; }
                aceito(results);
            });
        });
    },

    buscarFaltaMat: () =>{
        return new Promise ((aceito, rejeitado)=>{

            db.query ('SELECT * FROM Aluno WHERE falta_mat > 0', (error, results)=>{
                if (error){rejeitado(error); return; }
                aceito(results);
            });
        });
    },

    buscarFaltaHist: () =>{
        return new Promise ((aceito, rejeitado)=>{

            db.query ('SELECT * FROM Aluno WHERE falta_hist > 0', (error, results)=>{
                if (error){rejeitado(error); return; }
                aceito(results);
            });
        });
    },

    buscarFaltaHist: () =>{
        return new Promise ((aceito, rejeitado)=>{

            db.query ('SELECT * FROM Aluno WHERE falta_hist > 0', (error, results)=>{
                if (error){rejeitado(error); return; }
                aceito(results);
            });
        });
    },

    buscarFaltaCie: () =>{
        return new Promise ((aceito, rejeitado)=>{

            db.query ('SELECT * FROM Aluno WHERE falta_cie > 0', (error, results)=>{
                if (error){rejeitado(error); return; }
                aceito(results);
            });
        });
    },

    buscarFaltaArt: () =>{
        return new Promise ((aceito, rejeitado)=>{

            db.query ('SELECT * FROM Aluno WHERE falta_art > 0', (error, results)=>{
                if (error){rejeitado(error); return; }
                aceito(results);
            });
        });
    },

    buscarFaltaPort: () =>{
        return new Promise ((aceito, rejeitado)=>{

            db.query ('SELECT * FROM Aluno WHERE falta_port > 0', (error, results)=>{
                if (error){rejeitado(error); return; }
                aceito(results);
            });
        });
    },

    buscarFaltaIng: () =>{
        return new Promise ((aceito, rejeitado)=>{

            db.query ('SELECT * FROM Aluno WHERE falta_ing> 0', (error, results)=>{
                if (error){rejeitado(error); return; }
                aceito(results);
            });
        });
    },

    buscarFaltaGeo: () =>{
        return new Promise ((aceito, rejeitado)=>{

            db.query ('SELECT * FROM Aluno WHERE falta_geo> 0', (error, results)=>{
                if (error){rejeitado(error); return; }
                aceito(results);
            });
        });
    },

    buscarFaltaEdf: () =>{
        return new Promise ((aceito, rejeitado)=>{

            db.query ('SELECT * FROM Aluno WHERE falta_edf> 0', (error, results)=>{
                if (error){rejeitado(error); return; }
                aceito(results);
            });
        });
    },

    buscarReprovados:() =>{
        return new Promise ((aceito, rejeitado)=>{

            db.query ('SELECT * FROM Aluno WHERE reprovado=TRUE', (error, results)=>{
                if (error){rejeitado(error); return; }
                aceito(results);
            });
        });
    },


    
    
    
    
}